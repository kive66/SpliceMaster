namespace SpliceMaster {
    /** Accidentals */
    public enum Accid {
        None, Sharp, Flat, Natural
    }
}