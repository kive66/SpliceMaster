﻿using System.Windows.Controls;

namespace DMSkin.CloudMusic.View
{
    public partial class PageCloudMusic : Page
    {
        public PageCloudMusic()
        {
            InitializeComponent();
        }

        private void DataGrid_SelectionChanged() {

        }
    }
}
