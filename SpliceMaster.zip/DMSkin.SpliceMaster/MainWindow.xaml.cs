﻿using System.Collections.Generic;
using DMSkin.CloudMusic.ViewModel;

namespace DMSkin.CloudMusic
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ImageRadioButton_Checked(object sender, System.Windows.RoutedEventArgs e) {

        }

        private void ImageRadioButton_Checked_1(object sender, System.Windows.RoutedEventArgs e) {

        }

        private void ImageRadioButton_Checked_2(object sender, System.Windows.RoutedEventArgs e) {

        }

        private void Frame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e) {

        }

        private void DMSystemCloseButton_Click(object sender, System.Windows.RoutedEventArgs e) {

        }

        private void Button_Click(object sender, System.Windows.RoutedEventArgs e) {

        }
    }
}
